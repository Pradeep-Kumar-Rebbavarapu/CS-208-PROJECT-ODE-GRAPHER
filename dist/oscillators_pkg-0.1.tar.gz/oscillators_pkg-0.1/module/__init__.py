from kuramoto import Kuramoto
from plotting import plot_activity, plot_phase_coherence
